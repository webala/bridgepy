# `bridgepy`

`bridgepy` is a python packege that interacts with safaricom daraja api. 